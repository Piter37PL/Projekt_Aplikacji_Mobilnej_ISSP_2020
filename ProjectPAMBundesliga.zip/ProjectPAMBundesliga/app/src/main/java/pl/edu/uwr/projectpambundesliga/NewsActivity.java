package pl.edu.uwr.projectpambundesliga;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.TypedArray;
import android.view.View;

import java.util.ArrayList;

//Ekran z wyborem newsa (wiadomości) - CARDVIEW
public class NewsActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private ArrayList<News> mNewsData;
    private NewsAdapter mAdapterNews;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        mRecyclerView = findViewById(R.id.recyclerView);

        mRecyclerView.setLayoutManager(new GridLayoutManager(this,1));

        mNewsData = new ArrayList<>();

        mAdapterNews = new NewsAdapter(this,mNewsData);
        mRecyclerView.setAdapter(mAdapterNews);

        initializeData();

    }

    //Inicjalizacja dancych (Tytułu, tekstu i obrazka newsa)
    private void initializeData(){

        String [] newsTitleList = getResources().getStringArray(R.array.news_title);
        String [] newsTextList = getResources().getStringArray(R.array.news_text);
        TypedArray newsImageResources = getResources().obtainTypedArray(R.array.news_image);

        mNewsData.clear();

        for(int i=0; i< newsTitleList.length; i++)
        {
            mNewsData.add(new News(newsTitleList[i],newsTextList[i],newsImageResources.getResourceId(i,0)));
        }

        newsImageResources.recycle();
        mAdapterNews.notifyDataSetChanged();
    }

    //Przyciski nawigacyjne
    public void SwitchToArrays(View view)
    {
        Intent ArraysSeason = new Intent(NewsActivity.this,ArraysSeasonMenuActivity.class);
        startActivity(ArraysSeason);
    }

    public void SwitchToHistory(View view)
    {
        Intent HistoryMenu = new Intent(NewsActivity.this, HistoryMenuActivity.class);
        startActivity(HistoryMenu);
    }

}
