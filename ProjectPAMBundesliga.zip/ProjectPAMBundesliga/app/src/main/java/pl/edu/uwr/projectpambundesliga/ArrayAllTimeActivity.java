package pl.edu.uwr.projectpambundesliga;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;

public class ArrayAllTimeActivity extends AppCompatActivity {

    private TextView tx;
    private ListView lv;
    private ArrayAdapter<String> adapterA;

    private String textHeader = "Miejsce  -  Klub  -  Sezony  -  Z  -  R  -  P  - Pkt";
    private String AATH;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_array_all_time);

        Intent AS = getIntent();
        AATH = AS.getStringExtra(ArraysSeasonMenuActivity.EXTRA_ID);     //Adres pliku .php - wybrany

        adapterA = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);

        lv = findViewById(R.id.lv);
        tx = findViewById(R.id.headerTable);


        lv.setAdapter(adapterA);            //Załadowanie ArrayAdapter<String>

        tx.setText(textHeader);             //Załadowanie tekstu nagłówek

        new Connection().execute(AATH);      //Przekazanie do klasy Connection w celu połączenie się z bazą danych
    }

    //AsyncTask - łączenie się z bazą danych
    class Connection extends AsyncTask<String,String,String> {

        //Połączenie się z bazą danych i pobranie wyników
        @Override
        protected String doInBackground(String... strings) {

            String result="";
            String host = strings[0];

            try {
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(host));
                HttpResponse response = client.execute(request);
                BufferedReader readTable = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

                StringBuffer stringBuffer = new StringBuffer("");

                String line = "";
                while((line = readTable.readLine()) != null)
                {
                    stringBuffer.append(line);
                    break;
                }
                readTable.close();
                result = stringBuffer.toString();
            }
            catch(Exception e)
            {
                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
            }

            return result;
        }

        //W metodzie onPostExecute przygotowuje poprzez Obiekty JSON tabele do wyświetlenia
        @Override
        protected void onPostExecute(String result){
            try {
                JSONObject jsonResult = new JSONObject(result);
                int success = jsonResult.getInt("success");
                if(success==1)
                {
                    JSONArray clubs = jsonResult.getJSONArray("clubs");
                    for(int i=0; i<clubs.length(); i++)
                    {
                        JSONObject club = clubs.getJSONObject(i);

                        int Miej = club.getInt("Miejsce");
                        String Klub = club.getString("Klub");
                        int S = club.getInt("Sezony");
                        int Z = club.getInt("Z");
                        int R = club.getInt("R");
                        int P = club.getInt("P");
                        int Pkt = club.getInt("Pkt");

                        String line = Miej + "  " + Klub + "  " + S + "  " + Z + "  " + R + "  " + P + "  " + Pkt;
                        adapterA.add(line);
                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Isn't work",Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
            }

        }
    }

    //Przyciski nawigacyjne
    public void SwitchToNews(View view) {
        Intent MainMenu = new Intent(ArrayAllTimeActivity.this,NewsActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToHistory(View view){
        Intent HistoryMenu = new Intent(ArrayAllTimeActivity.this,HistoryMenuActivity.class);
        startActivity(HistoryMenu);
    }
}
