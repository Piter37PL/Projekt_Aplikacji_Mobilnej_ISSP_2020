package pl.edu.uwr.projectpambundesliga;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;

public class BundesligaHistoryActivity extends AppCompatActivity {

    private String [] Chapters = {                  //Tytuły rozdziałów historii do wyświetlenia
            "Początek",
            "Pierwszy mecz",
            "System rozgrywek"
    };

    private String[] ChaptersID = new String[]{     //id Textview dla treści rodziałów
            "ChapterText1",
            "ChapterText2",
            "ChapterText3"
    };

    private String[] History = new String[]{        //Tablica przechowująca treść z plików .txt (folder assest)
            "","",""
    };

    private String[] HistoryID = new String[]{      //id Textview dla treści historii
            "HistoryText1",
            "HistoryText2",
            "HistoryText3"
    };

    private String[] Image = new String[]{      //Tablica przechowująca obrazki w formacie jpg (folder drawable)
            "bh1","bh2","bh3"
    };

    private String[] ImageID = new String[]{    //id ImageView dla obrazków
            "ImageText1",
            "ImageText2",
            "ImageText3"
    };

    int textChaptersCount = Chapters.length;        //Rozmiar tablic
    int textHistoryCount = History.length;
    int textImageCount = Image.length;

    private TextView[] ChapterText = new TextView[textChaptersCount];  //Tablica TextView
    private TextView [] HistoryText = new TextView[textHistoryCount];  //Tablica TextView
    private ImageView[] ImageText = new ImageView[textImageCount];     //Tablica ImageView


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bundesliga_history);

        int tempC = 0;      //Zmienne tymczasowe do zapisu i załadowania id Textview/ImageView oraz obrazka
        int tempH = 0;
        int tempI = 0;
        int tempIread = 0;

        //Wczytywanie TextView, odnajdowanie po id oraz załadowanie tekstu
        for(int i = 0; i < textChaptersCount; i++){
            ChapterText[i] = new TextView(this);
            tempC = getResources().getIdentifier(ChaptersID[i],"id",getPackageName());
            ChapterText[i] = findViewById(tempC);
            ChapterText[i].setText(Chapters[i]);
        }

        //Treść plików załadowanych z plików txt do zmiennej string
        try {
            History[0] += ReaderText("Początek.txt");
            History[1] += ReaderText("Pierwszy_mecz.txt");
            History[2] += ReaderText("System_rozgrywek.txt");
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }

        //Wczytywanie TextView, odnajdowanie po id oraz załadowanie tekstu
        for(int i=0; i<textHistoryCount; i++){
            HistoryText[i] = new TextView(this);
            tempH = getResources().getIdentifier(HistoryID[i],"id",getPackageName());
            HistoryText[i] = findViewById(tempH);
            HistoryText[i].setText(History[i]);

        }

        //Wczytywanie ImageView, odnajdowanie po id oraz załadowanie obrazków
        for(int i=0; i<textImageCount; i++){
            ImageText[i] = new ImageView(this);
            tempI = getResources().getIdentifier(ImageID[i],"id",getPackageName());
            tempIread = getResources().getIdentifier(Image[i],"drawable",getPackageName());
            ImageText[i] = findViewById(tempI);
            ImageText[i].setImageResource(tempIread);
        }
    }

    //Metoda odczytu i zapisu do zmiennej treści z pliku .txt (folder assest)
    public String ReaderText(String filePath) throws IOException {
        String text = "";
        InputStream is = getAssets().open(filePath);
        int size = is.available();
        byte[] buffer = new byte[size];
        is.read(buffer);
        is.close();
        text = new String(buffer);
        return text;
    }

    //Przyciski nawigacyjne
    public void SwitchToNews(View view) {
        Intent MainMenu = new Intent(BundesligaHistoryActivity.this,NewsActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToArrays(View view){
        Intent ArraysSeason = new Intent(BundesligaHistoryActivity.this,ArraysSeasonMenuActivity.class);
        startActivity(ArraysSeason);
    }
}
