package pl.edu.uwr.projectpambundesliga;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

//Stworzenie RecycleView dla CardView
class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder>
{
    private ArrayList<News> mNewsData;
    private Context mContext;

    NewsAdapter(Context context, ArrayList<News> newsdata)
    {
        this.mNewsData = newsdata;
        this.mContext = context;
    }

    @Override
    public NewsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        return new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false));
    }

    @Override
    public void onBindViewHolder(NewsAdapter.ViewHolder holder, int position) {
        News currentNews = mNewsData.get(position);
        holder.bindTo(currentNews);
    }

    @Override
    public int getItemCount() {
        return mNewsData.size();
    }

    //Odnajdowanie elementów aplikacji, przepisanie przez id i załadowanie treści
    class ViewHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener{

        private TextView mTitleText;
        private ImageView mNewsImage;

        ViewHolder(View itemView) {
            super(itemView);

            mTitleText = itemView.findViewById(R.id.Newstitle);
            mNewsImage = itemView.findViewById(R.id.NewsImage);

            itemView.setOnClickListener(this);
        }


        void bindTo(News currentNews){
            mTitleText.setText(currentNews.getTitle());
            Glide.with(mContext).load(
                    currentNews.getImageResource()).into(mNewsImage);

        }

        //Przejście do DetailNewsActivity i przesłanie jej informacji o treści
        @Override
        public void onClick(View view) {
            News currentNews = mNewsData.get(getAdapterPosition());
            Intent detailIntent = new Intent(mContext, DetailNewsActivity.class);
            detailIntent.putExtra("title", currentNews.getTitle());
            detailIntent.putExtra("image_resource", currentNews.getImageResource());
            detailIntent.putExtra("text",currentNews.getTextNews());
            mContext.startActivity(detailIntent);
        }
    }
}
