package pl.edu.uwr.projectpambundesliga;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class ClubActivity extends AppCompatActivity {

    private String ClubId = "";
    private String ChooseSquad = "";
    private boolean validClub = false;
    private ImageView mLogoClub;

    public static final String EXTRA_TABLE = "pl.edu.uwr.projectpambundesliga";


    private String[] hostCS = new String[]{
            "http://192.168.8.117/android/Bundesliga/BAYsquad.php",       //Adres plików .php łączyc się z bazą danych
            "http://192.168.8.117/android/Bundesliga/BORsquad.php",       //phpmyadmin (XAMPP)
            "http://192.168.8.117/android/Bundesliga/LEVsquad.php",       //, w celu uzyskania i wyświetlenia tabel
            "http://192.168.8.117/android/Bundesliga/S04squad.php",       //adres przesyłam przez intencje
            "http://192.168.8.117/android/Bundesliga/WERsquad.php"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club);

        //przypisanie przesłanego id klubu z ClubsHistoryActivity.
        Intent Club = getIntent();
        ClubId = Club.getStringExtra(ClubsHistoryActivity.EXTRA_ID);

        mLogoClub = findViewById(R.id.LogoClub);
        SelectedClub();
    }

    //Switch do wybrania klubu i załadowanie logą jako informacja jaki klub
    public void SelectedClub()
    {
        switch(ClubId){
            case "BAY":
                mLogoClub.setImageResource(R.drawable.logobay);
                ChooseSquad = hostCS[0];
                validClub = true;
                break;
            case "BVB":
                mLogoClub.setImageResource(R.drawable.logobvb);
                ChooseSquad = hostCS[1];
                validClub = true;
                break;
            case "LEV":
                mLogoClub.setImageResource(R.drawable.logolev);
                ChooseSquad = hostCS[2];
                validClub = true;
                break;
            case "S04":
                mLogoClub.setImageResource(R.drawable.logos04);
                ChooseSquad = hostCS[3];
                validClub = true;
                break;
            case "WER":
                mLogoClub.setImageResource(R.drawable.logower);
                ChooseSquad = hostCS[4];
                validClub = true;
                break;
            default:
                mLogoClub.setImageResource(R.drawable.nologo);
                Toast.makeText(getApplicationContext(), "Błąd! Brak klubu", Toast.LENGTH_SHORT).show();
                validClub = false;
        }
    }

    //Przyciski nawigacyjne
    public void SwitchToNews(View view) {
        Intent MainMenu = new Intent(ClubActivity.this,NewsActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToArrays(View view){
        Intent ArraysSeason = new Intent(ClubActivity.this,ArraysSeasonMenuActivity.class);
        startActivity(ArraysSeason);
    }

    //Przejście do przeglądu składu danego klubu
    public void SquadClub(View view) {
        if(validClub == true)
        {
            Intent SC = new Intent(ClubActivity.this, ClubSquadActivity.class);
            SC.putExtra(EXTRA_TABLE,ChooseSquad);
            startActivity(SC);
        }
    }
}
