package pl.edu.uwr.projectpambundesliga;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class ClubsHistoryActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "pl.edu.uwr.projectpambundesliga";

    //Tabela id przycisków
    private String[] ClubsID = new String[]{
            "BAY", "BVB", "LEV", "S04", "WER"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clubs_history);
    }

    //Wybór klubu i wysłanie informacji o dla jakiego klubu załadować jakie dane
    public void SwitchToClub(View view){

        String idSend = " ";

        switch (view.getId())
        {
            case R.id.BAY:
                idSend = ClubsID[0];
                break;
            case R.id.BVB:
                idSend = ClubsID[1];
                break;
            case R.id.LEV:
                idSend = ClubsID[2];
                break;
            case R.id.S04:
                idSend = ClubsID[3];
                break;
            case R.id.WER:
                idSend = ClubsID[4];
                break;
            default:
                Toast.makeText(getApplicationContext(), "Błąd! Brak klubu", Toast.LENGTH_SHORT).show();
        }

        //Intent do przełączenia się do któregoś z klubów. Przesłanie id_klubu do wybrania treści do wyświetlenia
        Intent ClubHistory = new Intent(ClubsHistoryActivity.this,ClubActivity.class);
        ClubHistory.putExtra(EXTRA_ID,idSend);
        startActivity(ClubHistory);
    }

    //Przyciski nawigacyjne
    public void SwitchToNews(View view) {
        Intent MainMenu = new Intent(ClubsHistoryActivity.this,NewsActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToArrays(View view){
        Intent ArraysSeason = new Intent(ClubsHistoryActivity.this,ArraysSeasonMenuActivity.class);
        startActivity(ArraysSeason);
    }
}