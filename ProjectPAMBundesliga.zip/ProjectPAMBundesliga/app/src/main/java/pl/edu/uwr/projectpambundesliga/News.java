package pl.edu.uwr.projectpambundesliga;

//Klasa z atrybutami newsa (tytuł, obrazek, tekst wiadomości)
public class News {
    private String Title;
    private String TextNews;
    private final int ImageResource;

    public News(String Title, String TextNews, int ImageResource){
        this.Title = Title;
        this.TextNews = TextNews;
        this.ImageResource = ImageResource;
    }

    String getTitle()
    {
        return Title;
    }

    String getTextNews()
    {
        return TextNews;
    }

    public int getImageResource()
    {
        return ImageResource;
    }
}