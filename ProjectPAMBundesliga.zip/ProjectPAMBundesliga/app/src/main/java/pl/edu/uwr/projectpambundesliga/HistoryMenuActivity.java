package pl.edu.uwr.projectpambundesliga;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Menu wyboru czego zobaczyć historie: ligi czy klubu
public class HistoryMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_menu);
    }

    //Przyciski nawigacyjne na dole ekranu
    public void SwitchToNews(View view) {
        Intent MainMenu = new Intent(HistoryMenuActivity.this,NewsActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToArrays(View view){
        Intent ArraysSeason = new Intent(HistoryMenuActivity.this,ArraysSeasonMenuActivity.class);
        startActivity(ArraysSeason);
    }

    //Przyciski wyboru historii Bundesligi lub konkretnego klubu
    public void SwitchToLigueHistory(View view) {
        Intent BundesligaHistory = new Intent(HistoryMenuActivity.this, BundesligaHistoryActivity.class);
        startActivity(BundesligaHistory);
    }

    public void SwitchToClubsHistory(View view){
        Intent ClubsHistoryMenu = new Intent(HistoryMenuActivity.this, ClubsHistoryActivity.class);
        startActivity(ClubsHistoryMenu);
    }
}
