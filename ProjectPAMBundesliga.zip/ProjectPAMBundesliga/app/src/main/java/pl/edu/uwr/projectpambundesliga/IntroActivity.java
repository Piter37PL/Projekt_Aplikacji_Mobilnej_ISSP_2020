package pl.edu.uwr.projectpambundesliga;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.media.MediaPlayer;

import java.util.Timer;
import java.util.TimerTask;

//Ekran startowy aplikacji
public class IntroActivity extends AppCompatActivity {

    private Timer timer;
    private MediaPlayer IntroMusic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        // Metoda do przełączenia się z ekranu startowego (z logiem ) do ekranu głównego (menu)
        // Timer służy do wywołania metody run() po 3 sekundach (delay: 3000);
        // Intent służy do przełączenia się z jednej aktywności do innej
        //MediaPlayer puszcza dźwięk przy ekranie startowym

        timer = new Timer();

        IntroMusic = MediaPlayer.create(getApplicationContext(), R.raw.bundesong);
        IntroMusic.start();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {

                Intent startAplication = new Intent(IntroActivity.this,NewsActivity.class);
                startActivity(startAplication);
            }
        },8000);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        IntroMusic.stop();
    }
}
