package pl.edu.uwr.projectpambundesliga;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailNewsActivity extends AppCompatActivity {
    //Załadowanie tytuł, tekstu i wiadomości do elementów aktywności (activiti_detail_news.xml)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_news);

        TextView NewsTitle = findViewById(R.id.NewsTitleDetail);
        ImageView NewsImage = findViewById(R.id.NewsImageDetail);
        TextView NewsText = findViewById(R.id.NewsTextDetail);

        NewsTitle.setText(getIntent().getStringExtra("title"));
        NewsText.setText(getIntent().getStringExtra("text"));
        Glide.with(this).load(getIntent().getIntExtra("image_resource",0)).into(NewsImage);
    }


}