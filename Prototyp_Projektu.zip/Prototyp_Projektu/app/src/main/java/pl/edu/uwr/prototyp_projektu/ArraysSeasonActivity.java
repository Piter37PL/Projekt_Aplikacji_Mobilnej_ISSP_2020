package pl.edu.uwr.prototyp_projektu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ArraysSeasonActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "pl.edu.uwr.prototyp_projektu";

    private String[] hostAS = new String[]{
            "http://192.168.8.117/android/Sezon1920.php",       //Adres plików .php łączyc się z bazą danych
            "http://192.168.8.117/android/Sezon1819.php",       //phpmyadmin (XAMPP)
            "http://192.168.8.117/android/Sezon1718.php",       //, w celu uzyskania i wyświetlenia tabel
            "http://192.168.8.117/android/Sezon1617.php",       //adres przesyłam przez intencje
            "http://192.168.8.117/android/Sezon1516.php"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arrays_season);
    }

    //Przyciski nawigacyjne
    public void SwitchToMenu(View view) {
        Intent MainMenu = new Intent(ArraysSeasonActivity.this,MenuActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToHistory(View view){
        Intent HistoryMenu = new Intent(ArraysSeasonActivity.this,HistoryMenuActivity.class);
        startActivity(HistoryMenu);
    }

    //Przyciski wyboru tabeli
    public void Season1920(View view) {
        Intent S1920 = new Intent(ArraysSeasonActivity.this,ASactivity.class);
        S1920.putExtra(EXTRA_ID,hostAS[0]);
        startActivity(S1920);
    }
	
	public void Season1819(View view) {
        Intent S1819 = new Intent(ArraysSeasonActivity.this,ASactivity.class);
        S1819.putExtra(EXTRA_ID,hostAS[1]);
        startActivity(S1819);
    }
	
	public void Season1718(View view) {
        Intent S1718 = new Intent(ArraysSeasonActivity.this,ASactivity.class);
        S1718.putExtra(EXTRA_ID,hostAS[2]);
        startActivity(S1718);
    }
	
	public void Season1617(View view) {
        Intent S1617 = new Intent(ArraysSeasonActivity.this,ASactivity.class);
        S1617.putExtra(EXTRA_ID,hostAS[3]);
        startActivity(S1617);
    }
	
	public void Season1516(View view) {
        Intent S1516 = new Intent(ArraysSeasonActivity.this,ASactivity.class);
        S1516.putExtra(EXTRA_ID,hostAS[4]);
        startActivity(S1516);
    }
}
