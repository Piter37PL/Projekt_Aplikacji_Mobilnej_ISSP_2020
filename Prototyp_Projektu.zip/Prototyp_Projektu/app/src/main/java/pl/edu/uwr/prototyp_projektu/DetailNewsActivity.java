package pl.edu.uwr.prototyp_projektu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailNewsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_news);

        TextView NewsTitle = findViewById(R.id.NewsTitleDetail);
        ImageView NewsImage = findViewById(R.id.NewsImageDetail);

        NewsTitle.setText(getIntent().getStringExtra("title"));

        Glide.with(this)
                .load(getIntent()
                        .getIntExtra("image_resource",0))
                .into(NewsImage);
    }


}
