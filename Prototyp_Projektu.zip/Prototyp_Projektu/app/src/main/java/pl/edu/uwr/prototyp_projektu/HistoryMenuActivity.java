package pl.edu.uwr.prototyp_projektu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class HistoryMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_menu);
    }

    public void SwitchToMenu(View view) {
        Intent MainMenu = new Intent(HistoryMenuActivity.this,MenuActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToArrays(View view){
        Intent ArraysSeason = new Intent(HistoryMenuActivity.this,ArraysSeasonActivity.class);
        startActivity(ArraysSeason);
    }

    public void SwitchToBundesligaHistory(View view) {
        Intent BundesligaHistory = new Intent(HistoryMenuActivity.this, BundesligaHistoryActivity.class);
        startActivity(BundesligaHistory);
    }

    public void SwitchToClubsHistoryMenu(View view){
        Intent ClubsHistoryMenu = new Intent(HistoryMenuActivity.this, ClubsHistoryMenuActivity.class);
        startActivity(ClubsHistoryMenu);
    }
}
