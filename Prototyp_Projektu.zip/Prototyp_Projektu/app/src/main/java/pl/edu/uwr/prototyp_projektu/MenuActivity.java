package pl.edu.uwr.prototyp_projektu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private ArrayList<News> mNewsData;
    private NewsAdapter mAdapterNews;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        mRecyclerView = findViewById(R.id.recyclerView);

        int gridColumnCount = getResources().getInteger(R.integer.grid_column_count);

        mRecyclerView.setLayoutManager(new GridLayoutManager(this,gridColumnCount));

        mNewsData = new ArrayList<>();

        mAdapterNews = new NewsAdapter(this,mNewsData);
        mRecyclerView.setAdapter(mAdapterNews);

        initializeData();

    }

    private void initializeData(){

        String [] newsList = getResources().getStringArray(R.array.news_title);
        String [] newsTextList = getResources().getStringArray(R.array.news_text);
        TypedArray newsImageResources = getResources().obtainTypedArray(R.array.news_image);

        mNewsData.clear();

        for(int i=0; i< newsList.length; i++)
        {
            mNewsData.add(new News(newsList[i],newsTextList[i],newsImageResources.getResourceId(i,0)));
        }

        newsImageResources.recycle();
        mAdapterNews.notifyDataSetChanged();
    }

    //Metoda SwitchToArrays służy do przełączenia się MenuActivity na ArraysSeasonActivity
    public void SwitchToArrays(View view)
    {
        Intent ArraysSeason = new Intent(MenuActivity.this,ArraysSeasonActivity.class);
        startActivity(ArraysSeason);
    }

    //Metoda SwitchToArrays służy do przełączenia się MenuActivity na HistoryMenuActivity
    public void SwitchToHistory(View view)
    {
        Intent HistoryMenu = new Intent(MenuActivity.this, HistoryMenuActivity.class);
        startActivity(HistoryMenu);
    }


}
