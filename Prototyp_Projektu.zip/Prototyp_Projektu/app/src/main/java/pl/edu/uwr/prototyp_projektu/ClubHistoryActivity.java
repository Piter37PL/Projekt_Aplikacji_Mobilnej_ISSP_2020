package pl.edu.uwr.prototyp_projektu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ClubHistoryActivity extends AppCompatActivity {

    private String ClubId = "";
    private TextView tekstID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_history);

        Intent Club = getIntent();
        ClubId = Club.getStringExtra(ClubsHistoryMenuActivity.EXTRA_ID);

        tekstID = findViewById(R.id.textNameClub);
        TextNameClub();

    }

    public void SwitchToMenu(View view) {
        Intent MainMenu = new Intent(ClubHistoryActivity.this,MenuActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToArrays(View view){
        Intent ArraysSeason = new Intent(ClubHistoryActivity.this,ArraysSeasonActivity.class);
        startActivity(ArraysSeason);
    }

    public void TextNameClub()
    {
        switch(ClubId){
            case "BAY":
                tekstID.setText(R.string.Club_nr_1);
                break;
            case "BOR":
                tekstID.setText(R.string.Club_nr_2);
                break;
            case "S04":
                tekstID.setText(R.string.Club_nr_3);
                break;
            case "WER":
                tekstID.setText(R.string.Club_nr_4);
                break;
            case "LEV":
                tekstID.setText(R.string.Club_nr_5);
                break;
            case "FFC":
                tekstID.setText(R.string.Club_nr_6);
                break;
            case "FFK":
                tekstID.setText(R.string.Club_nr_7);
                break;
            case "MON":
                tekstID.setText(R.string.Club_nr_8);
                break;
            case "RBL":
                tekstID.setText(R.string.Club_nr_9);
                break;
            case "FRA":
                tekstID.setText(R.string.Club_nr_10);
                break;
            case "WOL":
                tekstID.setText(R.string.Club_nr_11);
                break;
            case "BER":
                tekstID.setText(R.string.Club_nr_12);
                break;
            default:
                tekstID.setText("Error! Unknown Club !");
        }
    }
}
