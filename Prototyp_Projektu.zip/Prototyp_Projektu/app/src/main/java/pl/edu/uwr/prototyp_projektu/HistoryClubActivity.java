package pl.edu.uwr.prototyp_projektu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HistoryClubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_club);
    }
}
