package pl.edu.uwr.prototyp_projektu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.gsm.GsmCellLocation;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ClubsHistoryMenuActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "pl.edu.uwr.prototyp_projektu";

    private String[] ClubsID = new String[]{
            "BAY", "BOR", "S04", "WER",
            "LEV", "FFC", "FFK", "MON",
            "RBL", "FRA", "WOL", "BER"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clubs_history_menu);
    }

    public void SwitchToMenu(View view) {
        Intent MainMenu = new Intent(ClubsHistoryMenuActivity.this,MenuActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToArrays(View view){
        Intent ArraysSeason = new Intent(ClubsHistoryMenuActivity.this,ArraysSeasonActivity.class);
        startActivity(ArraysSeason);
    }

    public void SwitchToClub(View view){

        String idSend = " ";

        switch (view.getId())
        {
            case R.id.BAY:
                idSend = ClubsID[0];
                break;
            case R.id.BOR:
                idSend = ClubsID[1];
                break;
            case R.id.S04:
                idSend = ClubsID[2];
                break;
            case R.id.WER:
                idSend = ClubsID[3];
                break;
            case R.id.LEV:
                idSend = ClubsID[4];
                break;
            case R.id.FFC:
                idSend = ClubsID[5];
                break;
            case R.id.FFK:
                idSend = ClubsID[6];
                break;
            case R.id.MON:
                idSend = ClubsID[7];
                break;
            case R.id.RBL:
                idSend = ClubsID[8];
                break;
            case R.id.FRA:
                idSend = ClubsID[9];
                break;
            case R.id.WOL:
                idSend = ClubsID[10];
                break;
            case R.id.BER:
                idSend = ClubsID[11];
                break;

        }

        //Toast t = Toast.makeText(getApplicationContext(),idSend,Toast.LENGTH_LONG);
        //t.show();

        Intent ClubHistory = new Intent(ClubsHistoryMenuActivity.this,ClubHistoryActivity.class);
        ClubHistory.putExtra(EXTRA_ID,idSend);
        startActivity(ClubHistory);
    }

}
