package pl.edu.uwr.prototyp_projektu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;


public class BundesligaHistoryActivity extends AppCompatActivity {

    private String [] Chapters = {                  //Tytuły rozdziałów historii do wyświetlenia
            "Jak powstał Bundesliga",
            "Rozdział 2"
    };

    private String[] ChaptersID = new String[]{     //id Textview dla treści rodziałów
            "ChapterText1",
            "ChapterText2",
    };

    private String[] History = new String[]{        //Tablica przechowująca treść z plików .txt (folder assest)
            ""
    };

    private String[] HistoryID = new String[]{      //id Textview dla treści historii
            "HistoryText1",
            "HistoryText2"
    };

    int textChaptersCount = Chapters.length;        //Rozmiar tablic
    int textHistoryCount = History.length;

    private TextView [] ChapterText = new TextView[textChaptersCount];  //Tablice TextView
    private TextView [] HistoryText = new TextView[textHistoryCount];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bundesliga_history);


        int tempC = 0;      //Zmienne tymczasowe do zapisu i załadowania id Textview
        int tempH = 0;

        for(int i = 0; i < textChaptersCount; i++){
            ChapterText[i] = new TextView(this);
            tempC = getResources().getIdentifier(ChaptersID[i],"id",getPackageName());
            ChapterText[i] = findViewById(tempC);
            ChapterText[i].setText(Chapters[i]);
        }

        try {
            History[0] += ReaderText("Bundesliga_history.txt");
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }

        HistoryText[0] = new TextView(this);
        tempH = getResources().getIdentifier(HistoryID[0],"id",getPackageName());
        HistoryText[0] = findViewById(tempH);
        HistoryText[0].setText(History[0]);

    }

    public String ReaderText(String filePath) throws IOException {      //Metoda odczytu i zapisu do zmiennej treści z pliku .txt (folder assest)
        String text = "";
        InputStream is = getAssets().open(filePath);
        int size = is.available();
        byte[] buffer = new byte[size];
        is.read(buffer);
        is.close();
        text = new String(buffer);
        return text;
    }

    //Przyciski nawigacyjne
    public void SwitchToMenu(View view) {
        Intent MainMenu = new Intent(BundesligaHistoryActivity.this,MenuActivity.class);
        startActivity(MainMenu);
    }

    public void SwitchToArrays(View view){
        Intent ArraysSeason = new Intent(BundesligaHistoryActivity.this,ArraysSeasonActivity.class);
        startActivity(ArraysSeason);
    }
}
